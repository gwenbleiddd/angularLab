import { Component } from '@angular/core';
import { GetDataService } from '../get-data.service';
import { ActivatedRoute } from '@angular/router';
//import reviewData from '../../assets/data.json'
@Component({
  selector: 'app-reviews',
  templateUrl: './reviews.component.html',
  styleUrls: ['./reviews.component.css']
})
export class ReviewsComponent {
  constructor(private service:GetDataService,private currentRoute:ActivatedRoute){}
  
  Info:any = [];
  reviewId:any;
  userInput = '';
  
  ngOnInit(){
      //this.Info = reviewData;
      this.reviewId = this.currentRoute.snapshot.paramMap.get('id');
     this.service.getReviewData().subscribe(data=>{
       this.Info = data;
     })
  }
  getValue(val:string){
    console.warn(val)
    this.userInput = val;
  }
  submitConfirmation(event:any) {
    event.preventDefault();
    
  }
}
